<?php
class DATABASE_CONFIG {

	/*var $default = array(
		'driver' => 'mysql',
		'persistent' => false,
		'host' => 'db.cs.umss.edu.bo',
		'login' => 'hostingadm',
		'password' => 'yrtkn81216',
		'database' => 'hosting',
	);*/
        var $default = array(
		'driver' => 'mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'root',
		'password' => '',
		'database' => 'hosting',
	);
}
?>